package data;
import javab.iosend;
import java.lang.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class com extends HttpServlet
{
    String servletName;
    public void init (ServletConfig config) throws ServletException
	{
	   super.init(config);
	   servletName=getServletName();
}
public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
{
	iosend sumBean = new iosend();          
	request.setAttribute("show",sumBean);   
	try{
		double first=Double.parseDouble(request.getParameter("first"));
		double second=Double.parseDouble(request.getParameter("second"));
		double third=Double.parseDouble(request.getParameter("third"));
		sumBean.setFirst(first);
		sumBean.setSecond(second);
		sumBean.setThird(third);
		double sum=-1;
		sum=third*first+third*(third-1.0)*second/2;
		sumBean.setSum(sum);
		sumBean.setMess("�Ȳ����кͣ�");
		RequestDispatcher dispatcher=request.getRequestDispatcher("showResult.jsp");
	dispatcher.forward(request,response);
	}
	catch(Exception e){
		sumBean.setSum(-1);
		sumBean.setMess(""+e);
	}	
} 
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
{
	iosend sumBean = new iosend();       
	request.setAttribute("show",sumBean);       
	try{
		double first2=Double.parseDouble(request.getParameter("first2"));
		double second2=Double.parseDouble(request.getParameter("second2"));
		double third2=Double.parseDouble(request.getParameter("third2"));
		sumBean.setFirst(first2);
		sumBean.setSecond(second2);
		sumBean.setThird(third2);
		double sum2=-1;
		if(second2==1.0){
			sum2=third2*first2;
		}
		else
		{
			sum2=(first2 - first2*(Math.pow(second2,third2)))/(1 - second2);
		}
		sumBean.setSum(sum2);
		sumBean.setMess("�ȱ����кͣ�");
		RequestDispatcher dispatcher=request.getRequestDispatcher("showResult.jsp");
	dispatcher.forward(request,response);
	}
	catch(Exception e){
		sumBean.setSum(-1);
		sumBean.setMess(""+e);
	}
	
} 
}