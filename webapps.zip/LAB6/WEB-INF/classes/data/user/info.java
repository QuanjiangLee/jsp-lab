package user;
public class info 
{
	String username="",password="",backnews="",email="";
	public void setUsername(String name){
            username=name;
	}
	public String getUsername(){
		return username;
	}
	public void setPassword(String pwd){
            password=pwd;
	}
	public String getPassword(){
		return password;
	}
	public void setEmail(String em){
            email=em;
	}
	public String getEmail(){
		return email;
	}
	public void setBacknews(String bnews){
            backnews=bnews;
	}
	public String getBacknews(){
		return backnews;
	}	
}