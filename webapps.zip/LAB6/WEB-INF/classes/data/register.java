package data;
import user.info;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class register extends HttpServlet{
	public void init(ServletConfig config) throws ServletException{
		super.init(config);
		try{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
public void doPost(HttpServletRequest request,HttpServletResponse response ) throws ServletException,IOException{
	Connection con;
	Statement sql;
	info reg=new info();
	request.setAttribute("register",reg);
	String username=request.getParameter("username").trim();
	String password=request.getParameter("password").trim();
	String email=request.getParameter("email").trim();
	String url="jdbc:mysql://localhost:3306/userinfo";
	String backnews="";
try{
	reg.setUsername(username);
    reg.setEmail(email);
	con=DriverManager.getConnection(url,"root","li0717");
	String insertcondition="insert into info values('"+username+"','"+password+"','"+email+"')";
	sql=con.createStatement();
	int count=sql.executeUpdate(insertcondition);
    if(count>0)
    {
    reg.setBacknews("Register successful!");
   
    }  
    else{
    	reg.setBacknews("Information input error, please enter again!");
}
	con.close();
}
catch(SQLException ex){
	reg.setBacknews("Registration fails, the member may already exist!");
}
RequestDispatcher dispatcher=request.getRequestDispatcher("show.jsp");
	dispatcher.forward(request,response);
} 
public void doGet(HttpServletRequest request,HttpServletResponse response ) throws ServletException,IOException{
	doPost(request,response);
}
}
