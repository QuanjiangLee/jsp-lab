package data;
import user.info;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class login extends HttpServlet{
	public void init(ServletConfig config) throws ServletException{
		super.init(config);
		try{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
public void doPost(HttpServletRequest request,HttpServletResponse response ) throws ServletException,IOException{
	Connection con;
	Statement sql;
	info log=new info();
	request.setAttribute("login",log);
	String username=request.getParameter("username").trim();
	String password=request.getParameter("password").trim();
	String url="jdbc:mysql://localhost:3306/userinfo";
	String backnews="";
try{
	 log.setUsername(username);
	con=DriverManager.getConnection(url,"root","li0717");
	String condition="select * from info where username='"+username+"'and password='"+password+"'";
	sql=con.createStatement();
	ResultSet rs=sql.executeQuery(condition);
	boolean m=rs.next();
    if(m==true)
    {
    log.setBacknews("login successful!");
    }  
    else{
    	log.setBacknews("Information input error, please enter again!");
}
	con.close();
}
catch(SQLException ex){
	log.setBacknews("login fails, the member may already exist!"+ex);
}
RequestDispatcher dispatcher=request.getRequestDispatcher("showLoginMess.jsp");
	dispatcher.forward(request,response);
} 
public void doGet(HttpServletRequest request,HttpServletResponse response ) throws ServletException,IOException{
	doPost(request,response);
}
}
