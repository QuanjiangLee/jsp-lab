package MessBoard;
public class board{
	String title="";
	String name="";
	String date="";
	String allMessage="";
public String getTitle(){
	return title;	
}
public void  setTitle(String newTitle){
	title=newTitle;	
}
public String getName(){
	return name;	
}
public void  setName(String newName){
	name=newName;	
}
public String getDate(){
	return date;	
}
public void  setDate(String newDate){
	date=newDate;
}
public String getAllMessage(){
	return allMessage;	
}
public void  setAllMessage(String newAllMessage){
	allMessage=newAllMessage;	
}	
}