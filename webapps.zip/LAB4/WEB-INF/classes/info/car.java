package info;
public class car{
	String carnum="s--";
	String carname="vvv";
	String cardate="201644";
public String getCarnum(){
	return carnum;	
}
public void  setCarnum(String newCarnum){
	carnum=newCarnum;	
}
public String getCarname(){
	return carname;	
}
public void  setCarname(String newCarname){
	carname=newCarname;	
}
public String getCardate(){
	return cardate;	
}
public void  setCardate(String newCardate){
	cardate=newCardate;	
}
}