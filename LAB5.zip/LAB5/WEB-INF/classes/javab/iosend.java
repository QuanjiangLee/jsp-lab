package javab;
public class iosend
{
	double first,second,third,sum;
	String mess;

public void  setFirst(double newFirst){
	first=newFirst;	
}	
public double getFirst(){
	return first;	
}
public void  setSecond(double newSecond){
	second=newSecond;	
}
public double getSecond(){
	return second;	
}
public void  setThird(double newThird){
	third=newThird;	
}
public double getThird(){
	return third;	
}
public void  setSum( double s){
	sum=s;
}
public double getSum(){
	return sum;	
}
public void  setMess( String m){
	mess=m;
}
public String getMess(){
	return mess;	
}	
}
